/*******************************************/
/*             JOURNEY.JS                  */
/*     Datos para USER JOURNEY MAP         */   
/*          [DIU] UX Toolkit v1.0 2019     */                        
/*          ver 1.1 26/Feb/2022            */
/*******************************************/
    
/****  README:       */
/****  v.1.1 Incluye nombre de tu grupo de prácticas (Grupo.ID), curso académico y enlace a github ***/
/****  Modifica los datos para los Journey Map (uno para cada Persona)  */
/****  Usa los 6 pasos y sigue las instrucciones */   
/****  Las imagenes para  'Photo', 'feelX', 'imaX' están en carpeta ./photos **/
/****  Si se usan nuevas imágenes se deben añadir a esa carpeta **/
/****  Los valores de rating están entre 1..5 **/
/****  recursos de imágenes:  https://www.vectorstock.com/royalty-free-vectors/vectors-by_zdeneksasek ***/




angular.module("angular", [])
	.controller("controller", ["$scope", function($scope) { 
		$scope.Grupo_ID ="DIU1.teamposits";
        $scope.Curso ="2021/22";
        $scope.Github_ID ="https://github.com/dacal01/DIU";
        
		$scope.JourneyIndex = 0;
        
        $scope.Journeys = [
			{		
                
                /*************************************/
                /**** PRIMER USER JOURNEY MAP  *******/
                /*** Cambiar datos             *******/
                /*************************************/
                
				Id: 0,
				Name: "Anselmo Rodriguez",
                Photo: "hombre.jpg",
    
                /*** PASO #1: INSPIRACION ***/ 
                goal1: "quiere salir del pueblo con su novia e ir a la ciudad",
                touch1: "su casa",
                feel1: "4",
                con1: "cuadrar días libres con su novia",
                ima1: "cartoon-awaking.png",
				
                /*** PASO #2: DECICION ***/ 
                goal2: "Busca hosteles en granada que le ha recomendado su amigo",
                touch2: "Ordenador de la biblioteca",
                feel2: "2",
                con2: "Se lia mucho buscando en la web. Él solo quiere ver precios e imágenes.",
                ima2: "cartoon-PCangry.png",
                
                /*** PASO #3: ACTUA ***/ 
                
                goal3: "Llama a su novia que entiende un poco más que él para buscar los dos juntos.",
                touch3: "móvil",
                feel3: "2",
                con3: "Está preocupado porque le ha tenido que desvelar la sorpresa a su novia.",
                ima3: "cartoon-phone.png",
                
                /*** PASO #4: OBSERVA ***/ 
                
                goal4: "La novia, que tampoco entiende mucho, selecciona el más barato que encuentra.",
                touch4: "ordenador de la biblioteca",
                feel4: "4",
                con4: "Buscar opciones en el lugar que había seleccionado, viendo precios",
                ima4: "cartoon-PCtyping.png",
                
                 /*** PASO #5: ANALIZA ***/ 
                
                goal5: "Estan cansados de buscar y no enterarse mucho así que deciden reservar ya el que han encontrado.",
                touch5: "web Carlota Braun",
                feel5: "3",
                con5: "Llama a sus amigos (whatsapp no responen) para ver cual es su preferencia, tienen que reservar rápido por los precios",
                ima5: "cartoon-PCSurprised.png",
                
                
                /*** PASO #6: CONCLUSION ***/ 
                
                goal6: "Consigue reservar pero queda un poco triste ya que le ha tenido que desvelar la sorpresa a su novia",
                touch6: "ordenador",
                feel6: "2",
                con6: "Se ha visto un poco perdido con las tecnologías y no ha salido como quería",
                ima6: "cartoon-PChard.png",
                
			},
			{	
                /*************************************/
                /**** SEGUNDO USER JOURNEY MAP *******/
                /***      Cambiar datos        *******/
                /*************************************/
                
				Id: 1,
                Name: "Abby Jones",
                Photo: "mujer.jpg",
                
                 /*** PASO #1: INSPIRACION ***/ 
                goal1: "Quiere preparar un viaje con su familia, para aprender mucho mas sobre España y preparar mejor su erasmus",
                touch1: "agenda",
                feel1: "5",
                con1: "Sus padres no son tan apasiados con este tema como lo está ella",
                ima1: "cartoon-writting.png",
                
                /*** PASO #2: DECICION ***/ 
                goal2: "Preguntar a personas españolas de erasmus en su universidad y a los profesores relacionados con el erasmus a España",
                touch2: "Alumnos y profesores",
                feel2: "3",
                con2: "No entiende muy bien a los estudiantes españoles a los que pregunta y sus profesores tampoco saben mucho sobre el tema",
                ima2: "cartoon-teamthinking.png",
                
                /*** PASO #3: ACTUA ***/ 
                
                goal3: "Sus padres no tienen mucho interés en el viaje y lo tiene que organizar ella sola",
                touch3: "Ordenador",
                feel3: "1",
                con3: "Piensa que no va a poder y que al final se va a quedar sin viaje con su familia",
                ima3: "cartoon-PCangry.png",
                
                /*** PASO #4: OBSERVA ***/ 
                
                goal4: "Busca ofertas cerca de la playa en los lugares que más le han recomendado",
                touch4: "Ordenador (webapp)",
                feel4: "3",
                con4: "Las ofertas están en español, tiene que usar el traductor y consigue entender casi todo",
                ima4: "cartoon-PChappy.png",
                
                 /*** PASO #5: ANALIZA ***/ 
                
                goal5: "Reserva llamando por teléfono ",
                touch5: "Móvil (webapp)",
                feel5: "4",
                con5: "Aunque al principio no podia comunicarse porque el recepcionista era español, pronto se puso al teléfono uno que sabía inglés",
                ima5: "cartoon-phone-sitting.png",

                
                /*** PASO #6: CONCLUSION ***/ 
                
                goal6: "Completa la reserva y piensa que es perfecta",
                touch6: "Ordenador (reserva OK)",
                feel6: "4",
                con6: "El aparcamiento es muy limitado y tendrá que ir a casi todos los sitios andando para no tener que buscar aparcamiento",
                ima6: "cartoon-PChard.png",
                
                
                
			}
		];
        
		$scope.model = $scope.Journeys[0];

	}])



