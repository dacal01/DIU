/*******************************************/
/*             PERSONA.JS                  */
/*     Datos para PERSONA TEMPLATE         */   
/*          [DIU] UX Toolkit v1.0 2019     */                        
/*          ver 1.2 26/Feb/2022            */
/*******************************************/
    
/****  README:       */
/****  Modifica los datos para las Personas      */
/****  v.1.1 Incluye nombre de tu grupo de prácticas (Grupo.ID), curso académico y enlace a github ***/
/****  Las imagenes para  'Photo'  están en carpeta ./photos **/
/****  Si se usan nuevas imágenes se deben añadir a esa carpeta **/
/****  Los valores de rating están entre 1..5 **/
/****  recursos de imágenes:  https://www.vectorstock.com/royalty-free-vectors/vectors-by_zdeneksasek ***/



angular.module("angular", [])
	.controller("controller", ["$scope", function($scope) { 
        $scope.Grupo_ID ="DIU1.teamposits";
        $scope.Curso ="2021/22";
        $scope.Github_ID ="https://github.com/dacal01/DIU";
        
		$scope.PersonaIndex = 0;
		$scope.Personas = [
			{		
                
                
                /*************************************/
                /**** PRIMERA PERSONA          *******/
                /*** Cambiar datos             *******/
                /*************************************/
                
                
				Id: 0,
				Name: "Anselmo Rodriguez",
				Photo: "hombre.jpg",
				Quote: "La vida es bella como uno mismo",
				Age: 35,
				Occupation: "Trabaja en un matadero",
				Family: "Con pareja desde hace 4 meses",
				Location: "Huelva (Ayamonte)",
				Character: "Le gusta dar paseos por la naturaleza",
				PersonalityTraits: [
					{ Name: "Introvertido/reservado Vs  Extrov/activo ", Value: 2 },
					{ Name: "Realista/práctico  Vs    Intuición/imaginativo", Value: 4 },
					{ Name: "Racional/analitico  Vs   Emocional/impulsivo", Value: 3 },
					{ Name: "Flemático/apático  Vs   Colérico/visceral", Value: 2 }
				], 
				Goals: ["Disfrutar del tiempo libre, viajar", "Mudarme a una gran ciudad"],
				Frustrations: ["le gustaría hacer más planes con su novia pero tiene poco tiempo libre", "De pequeño quise ser pintor pero no tuve recursos en el pueblo, por eso quiero mudarme a una ciudad"],
				Bio: "Nació en Aracena, su familia nunca tuvo muchos recursos ya que se dedicaba a la ganadería, trabajo que estaba y está muy mal pagado, principalmente porque el pueblo no ofrecía muchas posibiblidades. Su padre, Pedro, se dedica a la crianza de vacas principalmente aunque también de algunos cerdos y su madre, María, se pasaba la mayor parte del tiempo haciendo las labores de la casa aunque si que llegó a trabajar en una guardería durante algunos años hasta que quedó embarazada de Anselmo y tuvo que dejar el trabajo. Anselmo fue un buen estudiante, pero los bajos recursos económicos no le permitieron ir a la universidad y pronto se metió a trabajar en el matadero de Ayamonte, que era de un amigo de su padre, donde fue bien recibido y donde sigue trabajando hoy día. A los 34, conocío a Esperanza, su actual novia, con la que ya lleva 4 meses de relación.",
				Tech: [
					{ Name: "TIC/Internet", Value: 1 },
					{ Name: "Movil", Value: 3 },
					{ Name: "RRSS", Value: 2 },
					{ Name: "Software", Value: 0 }
					
				], 
                Contextos: "Es el cumpleaños de su novia y quiere llevarla de viaje a la ciudad",  
				PreferredChannels: [
					{ Name: "Publicidad Tradicional", Value: 5 },
					{ Name: "Online & Social Media", Value: 2 },
					{ Name: "Recomendaciones & sugerencias", Value: 3 },
					{ Name: "Persona confianza (amigos, boca a boca)", Value: 5 }
				]
			},
			{	
                
                /*************************************/
                /**** SEGUNDA PERSONA          *******/
                /*** Cambiar datos             *******/
                /*************************************/
                
                
				Id: 1,
				Name: "Abby Jones",
				Photo: "mujer.jpg",
				Quote: "The rain in spain stays mainly in the plain",
				Age: 21,
				Occupation: "Estudiante de filología hispánica",
				Family: "Vive con sus padres, sus hermanos y su perro Scooby",
				Location: "Newcastle",
				Character: "Siempre está con sus amigos y le gusta mucho salir de fiesta.",
				PersonalityTraits: [
					{ Name: "Introvertido/reservado Vs  Extrov/activo ", Value: 4 },
					{ Name: "Realista/práctico  Vs    Intuición/imaginativo", Value: 3 },
					{ Name: "Racional/analitico  Vs   Emocional/impulsivo", Value: 2 },
					{ Name: "Flemático/apático  Vs   Colérico/visceral", Value: 4 }
				], 
				Goals: ["Le gustaría hacer un año de Erasmus en España.", "Quiere enamorarse de un español con chalet en la playa."],
				Frustrations: ["A pesar de que ama España este es su primer viaje a España ya que a sus padres no les gusta.", "Sus padres prefieren que se case con un inglés"],
				Bio: "Siempre ha vivido en Newcastle desde que nació. Vive en una familia con buen nivel de ingresos. Es la mayor de 3 hermanos, su hermano pequeño es muy pesado y siempre le molesta mientras estudia pero con su hermano mediano se lleva muy bien ya que solo se sacan un año y a veces salen juntos de fiesta. Su padre es un gran empresario y posee una fabrica de cervezas inglesa y su madre es profesora de universidad.",
				Tech: [
					{ Name: "TIC/Internet", Value: 4 },
					{ Name: "Mobile", Value: 5 },
					{ Name: "RRSS", Value: 5 },
					{ Name: "Software", Value: 2 }
					
				], 
                Contextos:   "Cree que es una buena oportunidad para descubrir España y mejorar su español" ,
				PreferredChannels: [
					{ Name: "Publicidad Tradicional (Ads)", Value: 1 },
					{ Name: "Online & Social Media", Value: 4 },
					{ Name: "Recomendaciones & sugerencias", Value: 3 },
					{ Name: "Persona confianza (amigos, boca a boca)", Value: 3 }
				]
			}
		];
		$scope.model = $scope.Personas[0];

	}])